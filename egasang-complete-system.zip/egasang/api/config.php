<?php
// E-GASANG — Database Configuration & Helpers
define('DB_HOST','localhost');
define('DB_NAME','egasang_db');
define('DB_USER','root');
define('DB_PASS',''); // Default XAMPP = empty

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
        } catch (PDOException $e) { jsonError('DB Error: '.$e->getMessage(), 500); }
    }
    return $pdo;
}

function jsonSuccess($data=null, string $msg='OK', int $code=200): void {
    http_response_code($code);
    echo json_encode(['success'=>true,'message'=>$msg,'data'=>$data]);
    exit;
}

function jsonError(string $msg, int $code=400): void {
    http_response_code($code);
    echo json_encode(['success'=>false,'message'=>$msg,'data'=>null]);
    exit;
}

function startSess(): void {
    if (session_status()===PHP_SESSION_NONE) {
        session_set_cookie_params(['lifetime'=>7200,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
        session_start();
    }
}

function requireAuth(): array {
    startSess();
    if (empty($_SESSION['user'])) jsonError('Unauthorized',401);
    return $_SESSION['user'];
}

function requireAdmin(): array {
    $u = requireAuth();
    if ($u['role']==='resident') jsonError('Admin only',403);
    return $u;
}

function logAct(int $uid, string $uname, string $action, string $type='', int $tid=0, string $detail=''): void {
    try { getDB()->prepare("INSERT INTO activity_logs(user_id,user_name,action,target_type,target_id,details)VALUES(?,?,?,?,?,?)")->execute([$uid,$uname,$action,$type,$tid?:null,$detail]); } catch(Exception $e){}
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(204);exit;}
